## v1.0.0:

* [COOK-1201] - Add support for CentOS, (later via) RHEL family

## v0.7.1:

* Current public release
